package com.unity3d.player;

interface IAssetPackManagerStatusQueryCallback
{
    void onStatusResult(final long p0, final String[] p1, final int[] p2, final int[] p3);
}
