package com.unity3d.player;

public interface IPermissionRequestCallbacks
{
    void onPermissionResult(final String[] p0, final int[] p1);
}
