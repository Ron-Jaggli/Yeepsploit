package com.instacart.truetime;

public final class R
{
    private R() {
    }
}
