package com.gameanalytics.sdk.android;

public final class BuildConfig
{
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "library";
    public static final String LIBRARY_PACKAGE_NAME = "com.gameanalytics.sdk.android";
}
