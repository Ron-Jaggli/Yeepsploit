package com.unity3d.player;

interface IAssetPackManagerMobileDataConfirmationCallback
{
    void onMobileDataConfirmationResult(final boolean p0);
}
