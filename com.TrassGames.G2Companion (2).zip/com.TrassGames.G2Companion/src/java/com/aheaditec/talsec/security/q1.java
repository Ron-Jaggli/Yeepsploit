package com.aheaditec.talsec.security;

import android.content.Context;

public final class q1 implements Runnable
{
    public final l1 a;
    public final Context b;
    
    public q1(final l1 a, final Context b) {
        this.a = a;
        this.b = b;
    }
    
    public void run() {
        this.a.a.d(this.b);
        this.a.b.c(this.b);
        this.a.d.d(this.b);
        final j0 s = this.a.s;
        if (s != null) {
            s.a(s.d.a());
        }
        this.a.j.b(this.b);
        this.a.k.b(this.b);
        this.a.l.b(this.b);
        this.a.p.a(this.b);
        this.a.q.a(this.b);
        this.a.r.d(this.b);
    }
}
