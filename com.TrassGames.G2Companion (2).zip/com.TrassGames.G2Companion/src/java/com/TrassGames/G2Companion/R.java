package com.TrassGames.G2Companion;

public final class R
{
    private R() {
    }
    
    public static final class mipmap
    {
        public static int app_icon = 2131558400;
        public static int app_icon_round = 2131558401;
        
        private mipmap() {
        }
    }
    
    public static final class string
    {
        public static int app_name = 2131623969;
        
        private string() {
        }
    }
}
