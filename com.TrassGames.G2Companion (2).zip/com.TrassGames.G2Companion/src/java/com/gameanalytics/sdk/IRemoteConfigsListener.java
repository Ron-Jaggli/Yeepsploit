package com.gameanalytics.sdk;

public interface IRemoteConfigsListener
{
    void onRemoteConfigsUpdated();
}
