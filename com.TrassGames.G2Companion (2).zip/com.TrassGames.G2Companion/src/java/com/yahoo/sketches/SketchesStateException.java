package com.yahoo.sketches;

public class SketchesStateException extends SketchesException
{
    private static final long serialVersionUID = 1L;
    
    public SketchesStateException(final String s) {
        super(s);
    }
}
