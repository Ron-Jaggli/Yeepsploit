package com.aheaditec.talsec_security;

public final class R
{
    private R() {
    }
}
