package com.aheaditec.talsec.security;

import java.util.Map;
import java.security.PublicKey;

public interface r0 extends J0
{
    public static final c a = c.a;
    public static final long b = 60L;
    
    f a();
    
    h b();
    
    g c();
    
    e d();
    
    d e();
    
    a f();
    
    b g();
    
    String i();
    
    long j();
    
    public interface a
    {
        String[] a();
        
        String[] b();
        
        String[] c();
    }
    
    public interface b
    {
        PublicKey a();
        
        String b();
    }
    
    public static final class c
    {
        public static final c a;
        public static final long b = 60L;
        
        static {
            a = new c();
        }
    }
    
    public interface d
    {
        boolean a();
        
        boolean b();
        
        String c();
        
        boolean d();
        
        String e();
    }
    
    public interface e
    {
        String a();
        
        String b();
        
        Long c();
    }
    
    public interface f
    {
        Integer a();
        
        Integer b();
        
        Integer c();
        
        Integer d();
        
        Integer e();
        
        Integer f();
        
        Integer g();
        
        Integer h();
        
        Integer i();
        
        Integer j();
        
        Integer k();
        
        Integer l();
        
        Integer m();
        
        Integer n();
        
        Integer o();
        
        Integer p();
        
        Integer q();
        
        Integer r();
        
        Integer s();
        
        Integer t();
    }
    
    public interface g
    {
        Long a();
        
        String[] b();
    }
    
    public interface h
    {
        Map<String, String> a();
        
        Integer b();
    }
}
