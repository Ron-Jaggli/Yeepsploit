package com.yahoo.sketches;

public class SketchesArgumentException extends SketchesException
{
    private static final long serialVersionUID = 1L;
    
    public SketchesArgumentException(final String s) {
        super(s);
    }
}
