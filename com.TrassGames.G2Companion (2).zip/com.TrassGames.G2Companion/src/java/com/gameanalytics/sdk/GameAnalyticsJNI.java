package com.gameanalytics.sdk;

import android.app.Activity;

public class GameAnalyticsJNI
{
    public static native void nativeSetContext(final Activity p0);
}
