package com.aheaditec.talsec.security;

public class Y extends m1
{
    public static final int b = -8884;
    
    public Y(final int n, final String s, final Throwable t) {
        super(n, s, t);
    }
}
