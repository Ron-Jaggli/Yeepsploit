package com.aheaditec.talsec_security.security;

import android.content.Context;

public final class Natives
{
    public static final Natives a;
    
    static {
        a = new Natives();
    }
    
    public final native byte[] a(final byte p0, final byte p1);
    
    public final native byte[] b(final byte p0, final byte p1);
    
    public final native byte[] c(final byte[] p0, final byte p1, final byte p2);
    
    public final native byte[] d(final byte[] p0, final byte[] p1, final byte[] p2, final byte[] p3, final byte[] p4, final byte[] p5, final byte p6, final byte p7);
    
    public final native byte[] e(final byte p0, final byte p1);
    
    public final native byte[] f(final byte p0, final byte p1);
    
    public final native byte[] g(final byte p0, final byte p1);
    
    public final native byte[] h(final Context p0, final byte[] p1, final byte p2, final byte p3);
    
    public final native byte[] i(final Context p0, final byte[] p1, final byte p2, final byte p3);
    
    public final native byte[] j(final Context p0, final byte[] p1, final byte p2, final byte p3);
    
    public final native byte[] l(final byte p0, final byte p1);
    
    public final native byte[] m(final byte p0, final byte p1);
    
    public final native byte[] n(final byte[] p0, final byte p1, final byte p2);
    
    public final native byte[] o(final byte p0, final byte p1);
    
    public final native byte[] p(final String p0, final byte p1, final byte p2);
    
    public final native byte[] q(final byte p0, final byte p1);
}
