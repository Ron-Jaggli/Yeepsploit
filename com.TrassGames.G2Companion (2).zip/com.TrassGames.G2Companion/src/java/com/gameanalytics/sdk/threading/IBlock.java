package com.gameanalytics.sdk.threading;

public interface IBlock
{
    void execute();
    
    String getName();
}
