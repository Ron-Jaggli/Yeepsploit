package com.unity3d.player;

interface IAssetPackManagerDownloadStatusCallback
{
    void onStatusUpdate(final String p0, final int p1, final long p2, final long p3, final int p4, final int p5);
}
