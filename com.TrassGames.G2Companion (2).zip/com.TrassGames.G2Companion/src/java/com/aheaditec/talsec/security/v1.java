package com.aheaditec.talsec.security;

import android.content.Context;

public class v1
{
    public final B0 a;
    public final o0 b;
    
    public v1(final Context context) {
        this.a = new B0(context);
        this.b = new o0(context);
    }
    
    public o0 a() {
        return this.b;
    }
    
    public B0 b() {
        return this.a;
    }
}
