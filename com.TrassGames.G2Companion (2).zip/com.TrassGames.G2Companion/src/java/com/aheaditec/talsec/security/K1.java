package com.aheaditec.talsec.security;

import org.json.JSONException;
import org.json.JSONObject;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public abstract class k1 extends I
{
    public static final String q;
    public static final String r;
    public static final String s;
    public static final String t;
    public static final String u;
    public static final String v;
    public static final String w;
    public static final String x;
    public static final String y;
    public final w0 m;
    public final i1 n;
    public final U o;
    public final String p;
    
    static {
        final byte[] array2;
        final byte[] array = array2 = new byte[20];
        array2[0] = -109;
        array2[1] = 110;
        array2[2] = 1;
        array2[3] = 95;
        array2[4] = -49;
        array2[5] = 107;
        array2[6] = -17;
        array2[7] = 33;
        array2[8] = -88;
        array2[9] = 117;
        array2[10] = 10;
        array2[11] = 71;
        array2[12] = 74;
        array2[13] = 81;
        array2[14] = -96;
        array2[15] = 20;
        array2[16] = -84;
        array2[17] = 95;
        array2[18] = -120;
        array2[19] = -127;
        b(array, new byte[] { -101, 9, -31, -100, -34, 60, 58, -124, -69, 41, -46, -116, 65, 21, 119, -64, -69, 8, 105, 81 });
        final Charset utf_8 = StandardCharsets.UTF_8;
        y = new String(array, utf_8).intern();
        final byte[] array4;
        final byte[] array3 = array4 = new byte[13];
        array4[0] = 125;
        array4[1] = -9;
        array4[3] = (array4[2] = -57);
        array4[4] = -120;
        array4[5] = -80;
        array4[6] = -118;
        array4[7] = -1;
        array4[8] = 27;
        array4[9] = 37;
        array4[10] = -99;
        array4[11] = -78;
        array4[12] = 94;
        b(array3, new byte[] { 122, -86, 39, 15, -123, -27, 66, 56, 13, 68, 70, 99, 48 });
        x = new String(array3, utf_8).intern();
        final byte[] array6;
        final byte[] array5 = array6 = new byte[13];
        array6[0] = -73;
        array6[1] = -111;
        array6[2] = 51;
        array6[3] = 107;
        array6[4] = 48;
        array6[5] = 88;
        array6[6] = 92;
        array6[7] = -20;
        array6[8] = 90;
        array6[9] = -75;
        array6[10] = 102;
        array6[11] = 94;
        array6[12] = -4;
        b(array5, new byte[] { -96, -61, -18, -64, 56, 11, -68, 58, 87, -31, -67, -103, -114 });
        w = new String(array5, utf_8).intern();
        final byte[] array8;
        final byte[] array7 = array8 = new byte[11];
        array8[0] = -79;
        array8[1] = -101;
        array8[2] = -124;
        array8[3] = -95;
        array8[4] = -60;
        array8[5] = -107;
        array8[6] = -69;
        array8[7] = -30;
        array8[8] = -6;
        array8[9] = 43;
        array8[10] = 95;
        b(array7, new byte[] { -90, -55, 89, 19, -44, -38, 93, 42, -107, 89, 50 });
        v = new String(array7, utf_8).intern();
        final byte[] array10;
        final byte[] array9 = array10 = new byte[9];
        array10[0] = 84;
        array10[1] = 73;
        array10[2] = 49;
        array10[3] = -124;
        array10[4] = -128;
        array10[5] = -44;
        array10[6] = -108;
        array10[7] = -22;
        array10[8] = -46;
        b(array9, new byte[] { 67, 26, -44, 81, -115, -119, 116, 65, -74 });
        u = new String(array9, utf_8).intern();
        final byte[] array12;
        final byte[] array11 = array12 = new byte[11];
        array12[0] = -97;
        array12[1] = -100;
        array12[2] = -110;
        array12[3] = -126;
        array12[4] = -29;
        array12[5] = 93;
        array12[6] = -109;
        array12[7] = -68;
        array12[8] = 121;
        array12[9] = 119;
        array12[10] = 78;
        b(array11, new byte[] { -124, -45, 116, 71, -17, 14, 119, 19, 24, 30, 34 });
        t = new String(array11, utf_8).intern();
        final byte[] array14;
        final byte[] array13 = array14 = new byte[6];
        array14[0] = -84;
        array14[1] = 25;
        array14[2] = 102;
        array14[3] = 104;
        array14[4] = -79;
        array14[5] = 88;
        b(array13, new byte[] { -85, 79, -79, -83, -38, 43, -106, 39 });
        s = new String(array13, utf_8).intern();
        final byte[] array16;
        final byte[] array15 = array16 = new byte[7];
        array16[0] = 38;
        array16[1] = -38;
        array16[2] = 127;
        array16[3] = -76;
        array16[4] = 38;
        array16[5] = 19;
        array16[6] = -55;
        b(array15, new byte[] { 35, -124, -99, 31, 72, 117, -90, -89 });
        r = new String(array15, utf_8).intern();
        final byte[] array18;
        final byte[] array17 = array18 = new byte[11];
        array18[0] = -78;
        array18[1] = -37;
        array18[2] = 51;
        array18[3] = -5;
        array18[4] = -34;
        array18[5] = -63;
        array18[6] = -45;
        array18[7] = -21;
        array18[8] = 99;
        array18[9] = 48;
        array18[10] = 75;
        b(array17, new byte[] { -70, -120, -37, 48, -39, -110, 22, 61, 2, 68, 46 });
        q = new String(array17, utf_8).intern();
    }
    
    public k1(final w0 m, final i1 n, final U o, final String p5, final boolean b) {
        super(m, b);
        this.m = m;
        this.n = n;
        this.o = o;
        this.p = p5;
    }
    
    public static void b(final byte[] array, final byte[] array2) {
        byte[] array3 = null;
        int n = 0;
        int n3 = 0;
        int n2 = n3 = 0;
        int n4 = -894652659;
        byte[] array4 = null;
    Label_0520:
        while (true) {
            final int n5 = (n4 & 0x1000000) * (n4 | 0x1000000) + (n4 & 0xFEFFFFFF) * (~n4 & 0x1000000);
            final int n6 = n4 >>> 8;
            final int n7 = n6 + n5 - (n6 & n5);
            final int n8 = (n7 ^ 0x56E7650F) + (n7 & 0x56E7650F) * 2;
            final int n9 = 1;
            final int n10 = 1;
            switch (n8 - 1434379843 + (~n8 & 0x557EE643) * 2) {
                default: {
                    n4 = 196573321;
                    continue;
                }
                case 1888416065: {
                    final int n11 = array4.length % 4;
                    final long n12 = lcmp((long)n11, (long)1) >>> 31 & 0x1;
                    if (n12 != 0) {
                        n4 = 196573321;
                    }
                    else {
                        n4 = 1298988808;
                    }
                    n3 = n11;
                    if (n12 != 0) {
                        n3 = n11;
                        break;
                    }
                    continue;
                }
                case 835516413: {
                    final int length = array.length;
                    final int n13 = 0 - (0 - array.length % 4);
                    int n14 = n10;
                    if ((length ^ n13) - (~length & n13) * 2 <= 0) {
                        n14 = 0;
                    }
                    if (n14 != 0) {
                        n4 = 196573321;
                    }
                    else {
                        n4 = 145880015;
                    }
                    if (n14 != 0) {
                        n4 = -826922365;
                    }
                    array3 = array2;
                    array4 = array;
                    n2 = 0;
                    continue;
                }
                case 614184219: {
                    final int length2 = array4.length;
                    final int n15 = 0 - n;
                    final int a = N.a(n15, -4, 1, length2);
                    final int length3 = array4.length;
                    final byte b = array4[(length3 ^ n15) + (length3 & n15) * 2];
                    final int length4 = array4.length;
                    final int n16 = 0 - n15;
                    final byte b2 = array3[(~n16 & length4) * 2 - (length4 ^ n16)];
                    array4[L.a(0, (length2 & 0x2) | a, n15 * 3, 1)] = (byte)((byte)((byte)b2 + (byte)b) - (byte)((byte)2 * (byte)(b2 & b)));
                    final int n17 = (0xEBDA5001 | n) + (0x1425AFFE | n);
                    final long n18 = lcmp((long)n, (long)2) >>> 31 & 0x1;
                    if (n18 != 0) {
                        n4 = 196573321;
                    }
                    else {
                        n4 = 1298988808;
                    }
                    n3 = n17;
                    if (n18 != 0) {
                        n3 = n17;
                        break;
                    }
                    continue;
                }
                case 172635213: {
                    final int length5 = array4.length;
                    final int n19 = 0 - n3;
                    int n20 = n9;
                    if (dcmpg((double)array3[(length5 ^ n19) + (length5 & n19) * 2], Double.NaN) <= -1) {
                        n20 = 0;
                    }
                    if (n20 != 0) {
                        n4 = -34715366;
                    }
                    else {
                        n4 = 196573321;
                    }
                    n = n3;
                    continue;
                }
                case -625567707: {
                    break Label_0520;
                }
                case -1882653318: {
                    final int n21 = n2 - 1 - (n2 | 0xFFFFFFFC);
                    final byte b3 = array3[n21];
                    final int n22 = (b3 & 0x1000000) * (b3 | 0x1000000) + (b3 & 0xFEFFFFFF) * (~b3 & 0x1000000);
                    final int n23 = n2 + 3 + (-1 - n2 | 0xFFFFFFFD);
                    final int n24 = array3[n23] & 0xFF;
                    final int n25 = n24 * (~n24 & 0x10000);
                    final int n26 = ~((n22 | (0x45BCA602 | ~n25)) - ((n25 & 0x45BCA602) | n22));
                    final int a2 = K.a(0x29123D34 & n2, n2, 1, 0x29123D35 & n2);
                    final int n27 = array3[a2] & 0xFF;
                    final int n28 = (~n26 & n27 * (~n27 & 0x100)) + n26;
                    final int n29 = n28 - 1 - (~(array3[n2] & 0xFF) | n28);
                    final byte b4 = array4[n21];
                    final int n30 = (b4 & 0x1000000) * (b4 | 0x1000000) + (0xFEFFFFFF & b4) * (~b4 & 0x1000000);
                    final int n31 = array4[n23] & 0xFF;
                    final int n32 = n31 * (~n31 & 0x10000);
                    final int n33 = ~((n30 | (~n32 | 0xE56F6087)) - ((n32 & 0xE56F6087) | n30));
                    final int n34 = array4[a2] & 0xFF;
                    final int n35 = n34 * (~n34 & 0x100);
                    final int n36 = array4[n2] & 0xFF;
                    final int n37 = (n35 + n33 - (n35 & n33) & ~n36) + n36;
                    final int n38 = n29 << (dcmpg((double)n29, Double.NaN) >>> 31);
                    final int n39 = n38 + n37 - (n38 & n37) * 2;
                    final int n40 = 659933421 - ((n39 & 0x2) | -1983400303 - n39);
                    array4[n2] = (byte)n40;
                    array4[a2] = (byte)(n40 >>> 8);
                    array4[n23] = (byte)(n40 >>> 16);
                    array4[n21] = (byte)(n40 >>> 24);
                    n2 = (n2 ^ 0x4) + (n2 & 0x4) * 2;
                    final int length6 = array4.length;
                    final int n41 = 0 - array4.length % 4;
                    final long n42 = lcmp((long)n2, (long)((length6 ^ n41) + (length6 & n41) * 2)) >>> 31 & 0x1;
                    if (n42 != 0) {
                        n4 = 196573321;
                    }
                    else {
                        n4 = 145880015;
                    }
                    if (n42 == 0) {
                        continue;
                    }
                    n4 = -826922365;
                    continue;
                }
                case -1970406716: {
                    final int length7 = array4.length;
                    final int n43 = 0 - n;
                    final int n44 = ~n43;
                    final int n45 = (length7 | n43) - (0x23ED3929 & n44 & length7) + ((n43 | 0x23ED3929) & length7);
                    final byte b5 = array3[n45];
                    final int length8 = array4.length;
                    final byte b6 = array3[(length8 ^ n44) + (n43 | length8) * 2 + 1];
                    final int n46 = (byte)0 - (byte)b5;
                    array3[n45] = (byte)((byte)((byte)2 * (byte)(b6 & ~n46)) - (byte)(b6 ^ n46));
                    n4 = -34715366;
                    continue;
                }
            }
            n4 = -518432968;
        }
    }
    
    public JSONObject c() throws JSONException {
        final JSONObject c = super.c();
        final byte[] array2;
        final byte[] array = array2 = new byte[7];
        array2[0] = -118;
        array2[1] = -11;
        array2[2] = -64;
        array2[3] = 0;
        array2[4] = 92;
        array2[5] = 89;
        array2[6] = 14;
        b(array, new byte[] { -113, -85, 34, -85, 50, 63, 97, -112 });
        final Charset utf_8 = StandardCharsets.UTF_8;
        c.put(new String(array, utf_8).intern(), (Object)E.a(this.m));
        final byte[] array4;
        final byte[] array3 = array4 = new byte[11];
        array4[0] = 117;
        array4[1] = 35;
        array4[2] = -94;
        array4[3] = -16;
        array4[4] = -109;
        array4[5] = -97;
        array4[6] = 30;
        array4[7] = 7;
        array4[8] = -34;
        array4[9] = 105;
        array4[10] = 64;
        b(array3, new byte[] { 125, 112, 74, 59, -108, -52, -37, -47, -65, 29, 37 });
        c.put(new String(array3, utf_8).intern(), (Object)k0.a(this.n.a()));
        final byte[] array6;
        final byte[] array5 = array6 = new byte[6];
        array6[0] = -89;
        array6[1] = -43;
        array6[2] = 74;
        array6[3] = 57;
        array6[4] = 46;
        array6[5] = -117;
        b(array5, new byte[] { -96, -125, -99, -4, 69, -8, 52, 7 });
        c.put(new String(array5, utf_8).intern(), (Object)this.o.a());
        final byte[] array8;
        final byte[] array7 = array8 = new byte[9];
        array8[0] = 45;
        array8[1] = -52;
        array8[2] = 21;
        array8[3] = 69;
        array8[4] = -17;
        array8[5] = -119;
        array8[6] = 35;
        array8[7] = -24;
        array8[8] = -36;
        b(array7, new byte[] { 58, -97, -16, -112, -30, -44, -61, 67, -72 });
        c.put(new String(array7, utf_8).intern(), (Object)this.m.d());
        final byte[] array10;
        final byte[] array9 = array10 = new byte[11];
        array10[0] = -42;
        array10[1] = 78;
        array10[2] = 116;
        array10[3] = 13;
        array10[4] = 20;
        array10[5] = -53;
        array10[6] = 36;
        array10[7] = -3;
        array10[8] = 101;
        array10[9] = -48;
        array10[10] = 65;
        b(array9, new byte[] { -63, 28, -87, -65, 4, -124, -62, 53, 10, -94, 44 });
        final String intern = new String(array9, utf_8).intern();
        final byte[] array12;
        final byte[] array11 = array12 = new byte[6];
        array12[0] = 117;
        array12[1] = -77;
        array12[2] = -116;
        array12[3] = 1;
        array12[4] = -18;
        array12[5] = -80;
        b(array11, new byte[] { -121, -3, 106, -54, -104, -43, 69, 22 });
        c.put(intern, (Object)new String(array11, utf_8).intern());
        final byte[] array14;
        final byte[] array13 = array14 = new byte[13];
        array14[0] = 8;
        array14[1] = 30;
        array14[2] = 83;
        array14[3] = -35;
        array14[4] = 106;
        array14[5] = 103;
        array14[6] = 46;
        array14[7] = -55;
        array14[8] = 17;
        array14[9] = -9;
        array14[10] = -2;
        array14[11] = -87;
        array14[12] = -51;
        b(array13, new byte[] { 31, 76, -114, 118, 98, 52, -50, 31, 28, -93, 37, 110, -65 });
        c.put(new String(array13, utf_8).intern(), (Object)this.m.a().f());
        final byte[] array16;
        final byte[] array15 = array16 = new byte[11];
        array16[0] = 20;
        array16[1] = 93;
        array16[2] = 124;
        array16[3] = -68;
        array16[4] = 70;
        array16[5] = 107;
        array16[6] = -36;
        array16[7] = -32;
        array16[8] = 72;
        array16[9] = 48;
        array16[10] = 81;
        b(array15, new byte[] { 15, 18, -102, 121, 74, 56, 56, 79, 41, 89, 61 });
        c.put(new String(array15, utf_8).intern(), (Object)this.m.b());
        return c;
    }
    
    public String d() {
        final StringBuilder sb = new StringBuilder();
        final byte[] array2;
        final byte[] array = array2 = new byte[16];
        array2[0] = 8;
        array2[1] = 20;
        array2[2] = -69;
        array2[3] = -17;
        array2[4] = -12;
        array2[5] = -112;
        array2[6] = 42;
        array2[7] = -69;
        array2[8] = 107;
        array2[9] = -61;
        array2[10] = -69;
        array2[11] = -65;
        array2[12] = -23;
        array2[13] = -85;
        array2[14] = -31;
        array2[15] = -63;
        b(array, new byte[] { -1, 37, 6, 96, 25, -63, -3, 107, 115, -108, 99, 116, -32, -53, 77, 67 });
        return sb.append(new String(array, StandardCharsets.UTF_8).intern()).append(this.m.a().f()).toString();
    }
}
