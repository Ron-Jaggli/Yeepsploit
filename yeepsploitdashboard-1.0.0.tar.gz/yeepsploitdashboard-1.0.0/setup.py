from setuptools import setup

setup(
    name="YeepsploitDashboard",
    author="SkepticalVR",
    description="A dashboard for Yeepsploit",
    long_description="",
    website="yeepsploit.org",
    version="1.0.0",
    py_modules=["main"],  # or packages=["yourpackage"]
    entry_points={
        "console_scripts": [
            "yourcommand = main:main",  # if main.py has a main() function
        ],
    },
    install_requires=[],  # list dependencies here
)