package com.UnityTechnologies.XR.Manifest;

public final class R
{
    private R() {
    }
}
