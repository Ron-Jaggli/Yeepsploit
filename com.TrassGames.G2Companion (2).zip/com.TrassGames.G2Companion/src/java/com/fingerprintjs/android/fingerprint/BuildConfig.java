package com.fingerprintjs.android.fingerprint;

public final class BuildConfig
{
    public static final String BUILD_TYPE = "release";
    public static final boolean CI_TEST = false;
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "com.fingerprintjs.android.fingerprint";
}
