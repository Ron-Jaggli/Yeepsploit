package com.aheaditec.talsec.security;

public interface g0
{
    String a();
    
    String b();
    
    String c();
    
    String d();
}
