package com.aheaditec.talsec.security;

public class j1 extends m1
{
    public static final int b = -7772;
    public static final int c = -7773;
    public static final int d = -7774;
    public static final int e = -7778;
    public static final int f = -7779;
    public static final int g = -7780;
    
    public j1(final int n, final String s) {
        super(n, s);
    }
    
    public j1(final int n, final String s, final Throwable t) {
        super(n, s, t);
    }
}
