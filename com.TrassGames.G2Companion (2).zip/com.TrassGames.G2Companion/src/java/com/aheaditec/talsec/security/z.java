package com.aheaditec.talsec.security;

public interface Z
{
    String a(final String p0);
}
