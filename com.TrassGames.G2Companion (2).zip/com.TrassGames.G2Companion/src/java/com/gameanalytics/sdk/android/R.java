package com.gameanalytics.sdk.android;

public final class R
{
    private R() {
    }
    
    public static final class attr
    {
        public static int alpha = 2130968619;
        public static int buttonSize = 2130968660;
        public static int circleCrop = 2130968681;
        public static int colorScheme = 2130968704;
        public static int font = 2130968794;
        public static int fontProviderAuthority = 2130968796;
        public static int fontProviderCerts = 2130968797;
        public static int fontProviderFetchStrategy = 2130968798;
        public static int fontProviderFetchTimeout = 2130968799;
        public static int fontProviderPackage = 2130968800;
        public static int fontProviderQuery = 2130968801;
        public static int fontStyle = 2130968803;
        public static int fontVariationSettings = 2130968804;
        public static int fontWeight = 2130968805;
        public static int imageAspectRatio = 2130968820;
        public static int imageAspectRatioAdjust = 2130968821;
        public static int scopeUris = 2130969009;
        public static int ttcIndex = 2130969117;
        
        private attr() {
        }
    }
    
    public static final class bool
    {
        public static int abc_action_bar_embed_tabs = 2131034112;
        
        private bool() {
        }
    }
    
    public static final class color
    {
        public static int common_google_signin_btn_text_dark = 2131099690;
        public static int common_google_signin_btn_text_dark_default = 2131099691;
        public static int common_google_signin_btn_text_dark_disabled = 2131099692;
        public static int common_google_signin_btn_text_dark_focused = 2131099693;
        public static int common_google_signin_btn_text_dark_pressed = 2131099694;
        public static int common_google_signin_btn_text_light = 2131099695;
        public static int common_google_signin_btn_text_light_default = 2131099696;
        public static int common_google_signin_btn_text_light_disabled = 2131099697;
        public static int common_google_signin_btn_text_light_focused = 2131099698;
        public static int common_google_signin_btn_text_light_pressed = 2131099699;
        public static int common_google_signin_btn_tint = 2131099700;
        public static int notification_action_color_filter = 2131099723;
        public static int notification_icon_bg_color = 2131099724;
        public static int primary_text_default_material_dark = 2131099729;
        public static int ripple_material_light = 2131099734;
        public static int secondary_text_default_material_dark = 2131099735;
        public static int secondary_text_default_material_light = 2131099736;
        
        private color() {
        }
    }
    
    public static final class dimen
    {
        public static int compat_button_inset_horizontal_material = 2131165265;
        public static int compat_button_inset_vertical_material = 2131165266;
        public static int compat_button_padding_horizontal_material = 2131165267;
        public static int compat_button_padding_vertical_material = 2131165268;
        public static int compat_control_corner_material = 2131165269;
        public static int compat_notification_large_icon_max_height = 2131165270;
        public static int compat_notification_large_icon_max_width = 2131165271;
        public static int notification_action_icon_size = 2131165282;
        public static int notification_action_text_size = 2131165283;
        public static int notification_big_circle_margin = 2131165284;
        public static int notification_content_margin_start = 2131165285;
        public static int notification_large_icon_height = 2131165286;
        public static int notification_large_icon_width = 2131165287;
        public static int notification_main_column_padding_top = 2131165288;
        public static int notification_media_narrow_margin = 2131165289;
        public static int notification_right_icon_size = 2131165290;
        public static int notification_right_side_padding_top = 2131165291;
        public static int notification_small_icon_background_padding = 2131165292;
        public static int notification_small_icon_size_as_large = 2131165293;
        public static int notification_subtext_size = 2131165294;
        public static int notification_top_pad = 2131165295;
        public static int notification_top_pad_large_text = 2131165296;
        
        private dimen() {
        }
    }
    
    public static final class drawable
    {
        public static int common_full_open_on_phone = 2131230807;
        public static int common_google_signin_btn_icon_dark = 2131230808;
        public static int common_google_signin_btn_icon_dark_focused = 2131230809;
        public static int common_google_signin_btn_icon_dark_normal = 2131230810;
        public static int common_google_signin_btn_icon_dark_normal_background = 2131230811;
        public static int common_google_signin_btn_icon_disabled = 2131230812;
        public static int common_google_signin_btn_icon_light = 2131230813;
        public static int common_google_signin_btn_icon_light_focused = 2131230814;
        public static int common_google_signin_btn_icon_light_normal = 2131230815;
        public static int common_google_signin_btn_icon_light_normal_background = 2131230816;
        public static int common_google_signin_btn_text_dark = 2131230817;
        public static int common_google_signin_btn_text_dark_focused = 2131230818;
        public static int common_google_signin_btn_text_dark_normal = 2131230819;
        public static int common_google_signin_btn_text_dark_normal_background = 2131230820;
        public static int common_google_signin_btn_text_disabled = 2131230821;
        public static int common_google_signin_btn_text_light = 2131230822;
        public static int common_google_signin_btn_text_light_focused = 2131230823;
        public static int common_google_signin_btn_text_light_normal = 2131230824;
        public static int common_google_signin_btn_text_light_normal_background = 2131230825;
        public static int googleg_disabled_color_18 = 2131230828;
        public static int googleg_standard_color_18 = 2131230829;
        public static int notification_action_background = 2131230830;
        public static int notification_bg = 2131230831;
        public static int notification_bg_low = 2131230832;
        public static int notification_bg_low_normal = 2131230833;
        public static int notification_bg_low_pressed = 2131230834;
        public static int notification_bg_normal = 2131230835;
        public static int notification_bg_normal_pressed = 2131230836;
        public static int notification_icon_background = 2131230837;
        public static int notification_template_icon_bg = 2131230838;
        public static int notification_template_icon_low_bg = 2131230839;
        public static int notification_tile_bg = 2131230840;
        public static int notify_panel_notification_icon_bg = 2131230841;
        
        private drawable() {
        }
    }
    
    public static final class id
    {
        public static int accessibility_action_clickable_span = 2131296267;
        public static int accessibility_custom_action_0 = 2131296268;
        public static int accessibility_custom_action_1 = 2131296269;
        public static int accessibility_custom_action_10 = 2131296270;
        public static int accessibility_custom_action_11 = 2131296271;
        public static int accessibility_custom_action_12 = 2131296272;
        public static int accessibility_custom_action_13 = 2131296273;
        public static int accessibility_custom_action_14 = 2131296274;
        public static int accessibility_custom_action_15 = 2131296275;
        public static int accessibility_custom_action_16 = 2131296276;
        public static int accessibility_custom_action_17 = 2131296277;
        public static int accessibility_custom_action_18 = 2131296278;
        public static int accessibility_custom_action_19 = 2131296279;
        public static int accessibility_custom_action_2 = 2131296280;
        public static int accessibility_custom_action_20 = 2131296281;
        public static int accessibility_custom_action_21 = 2131296282;
        public static int accessibility_custom_action_22 = 2131296283;
        public static int accessibility_custom_action_23 = 2131296284;
        public static int accessibility_custom_action_24 = 2131296285;
        public static int accessibility_custom_action_25 = 2131296286;
        public static int accessibility_custom_action_26 = 2131296287;
        public static int accessibility_custom_action_27 = 2131296288;
        public static int accessibility_custom_action_28 = 2131296289;
        public static int accessibility_custom_action_29 = 2131296290;
        public static int accessibility_custom_action_3 = 2131296291;
        public static int accessibility_custom_action_30 = 2131296292;
        public static int accessibility_custom_action_31 = 2131296293;
        public static int accessibility_custom_action_4 = 2131296294;
        public static int accessibility_custom_action_5 = 2131296295;
        public static int accessibility_custom_action_6 = 2131296296;
        public static int accessibility_custom_action_7 = 2131296297;
        public static int accessibility_custom_action_8 = 2131296298;
        public static int accessibility_custom_action_9 = 2131296299;
        public static int action_container = 2131296310;
        public static int action_divider = 2131296312;
        public static int action_image = 2131296313;
        public static int action_text = 2131296319;
        public static int actions = 2131296320;
        public static int adjust_height = 2131296323;
        public static int adjust_width = 2131296324;
        public static int async = 2131296334;
        public static int auto = 2131296335;
        public static int blocking = 2131296344;
        public static int bottom = 2131296345;
        public static int chronometer = 2131296361;
        public static int dark = 2131296373;
        public static int dialog_button = 2131296380;
        public static int end = 2131296400;
        public static int forever = 2131296408;
        public static int icon = 2131296421;
        public static int icon_group = 2131296422;
        public static int icon_only = 2131296423;
        public static int info = 2131296430;
        public static int italic = 2131296432;
        public static int left = 2131296436;
        public static int light = 2131296438;
        public static int line1 = 2131296439;
        public static int line3 = 2131296440;
        public static int none = 2131296454;
        public static int normal = 2131296455;
        public static int notification_background = 2131296457;
        public static int notification_main_column = 2131296458;
        public static int notification_main_column_container = 2131296459;
        public static int right = 2131296479;
        public static int right_icon = 2131296480;
        public static int right_side = 2131296481;
        public static int standard = 2131296518;
        public static int start = 2131296519;
        public static int tag_accessibility_actions = 2131296529;
        public static int tag_accessibility_clickable_spans = 2131296530;
        public static int tag_accessibility_heading = 2131296531;
        public static int tag_accessibility_pane_title = 2131296532;
        public static int tag_screen_reader_focusable = 2131296536;
        public static int tag_transition_group = 2131296538;
        public static int tag_unhandled_key_event_manager = 2131296539;
        public static int tag_unhandled_key_listeners = 2131296540;
        public static int text = 2131296542;
        public static int text2 = 2131296543;
        public static int time = 2131296546;
        public static int title = 2131296547;
        public static int top = 2131296551;
        public static int wide = 2131296570;
        
        private id() {
        }
    }
    
    public static final class integer
    {
        public static int cancel_button_image_alpha = 2131361794;
        public static int google_play_services_version = 2131361796;
        public static int status_bar_notification_info_maxnum = 2131361797;
        
        private integer() {
        }
    }
    
    public static final class layout
    {
        public static int custom_dialog = 2131492892;
        public static int notification_action = 2131492894;
        public static int notification_action_tombstone = 2131492895;
        public static int notification_template_custom_big = 2131492896;
        public static int notification_template_icon_group = 2131492897;
        public static int notification_template_part_chronometer = 2131492898;
        public static int notification_template_part_time = 2131492899;
        
        private layout() {
        }
    }
    
    public static final class string
    {
        public static int app_name = 2131623969;
        public static int common_google_play_services_enable_button = 2131623970;
        public static int common_google_play_services_enable_text = 2131623971;
        public static int common_google_play_services_enable_title = 2131623972;
        public static int common_google_play_services_install_button = 2131623973;
        public static int common_google_play_services_install_text = 2131623974;
        public static int common_google_play_services_install_title = 2131623975;
        public static int common_google_play_services_notification_channel_name = 2131623976;
        public static int common_google_play_services_notification_ticker = 2131623977;
        public static int common_google_play_services_unknown_issue = 2131623978;
        public static int common_google_play_services_unsupported_text = 2131623979;
        public static int common_google_play_services_update_button = 2131623980;
        public static int common_google_play_services_update_text = 2131623981;
        public static int common_google_play_services_update_title = 2131623982;
        public static int common_google_play_services_updating_text = 2131623983;
        public static int common_google_play_services_wear_update_text = 2131623984;
        public static int common_open_on_phone = 2131623985;
        public static int common_signin_button_text = 2131623986;
        public static int common_signin_button_text_long = 2131623987;
        public static int status_bar_notification_info_overflow = 2131624002;
        
        private string() {
        }
    }
    
    public static final class style
    {
        public static int TextAppearance_Compat_Notification = 2131689711;
        public static int TextAppearance_Compat_Notification_Info = 2131689712;
        public static int TextAppearance_Compat_Notification_Line2 = 2131689713;
        public static int TextAppearance_Compat_Notification_Time = 2131689714;
        public static int TextAppearance_Compat_Notification_Title = 2131689715;
        public static int Widget_Compat_NotificationActionContainer = 2131689826;
        public static int Widget_Compat_NotificationActionText = 2131689827;
        
        private style() {
        }
    }
    
    public static final class styleable
    {
        public static int[] ColorStateListItem;
        public static int ColorStateListItem_alpha = 3;
        public static int ColorStateListItem_android_alpha = 1;
        public static int ColorStateListItem_android_color = 0;
        public static int ColorStateListItem_android_lStar = 2;
        public static int ColorStateListItem_lStar = 4;
        public static int[] FontFamily;
        public static int[] FontFamilyFont;
        public static int FontFamilyFont_android_font = 0;
        public static int FontFamilyFont_android_fontStyle = 2;
        public static int FontFamilyFont_android_fontVariationSettings = 4;
        public static int FontFamilyFont_android_fontWeight = 1;
        public static int FontFamilyFont_android_ttcIndex = 3;
        public static int FontFamilyFont_font = 5;
        public static int FontFamilyFont_fontStyle = 6;
        public static int FontFamilyFont_fontVariationSettings = 7;
        public static int FontFamilyFont_fontWeight = 8;
        public static int FontFamilyFont_ttcIndex = 9;
        public static int FontFamily_fontProviderAuthority = 0;
        public static int FontFamily_fontProviderCerts = 1;
        public static int FontFamily_fontProviderFetchStrategy = 2;
        public static int FontFamily_fontProviderFetchTimeout = 3;
        public static int FontFamily_fontProviderPackage = 4;
        public static int FontFamily_fontProviderQuery = 5;
        public static int FontFamily_fontProviderSystemFontFamily = 6;
        public static int[] GradientColor;
        public static int[] GradientColorItem;
        public static int GradientColorItem_android_color = 0;
        public static int GradientColorItem_android_offset = 1;
        public static int GradientColor_android_centerColor = 7;
        public static int GradientColor_android_centerX = 3;
        public static int GradientColor_android_centerY = 4;
        public static int GradientColor_android_endColor = 1;
        public static int GradientColor_android_endX = 10;
        public static int GradientColor_android_endY = 11;
        public static int GradientColor_android_gradientRadius = 5;
        public static int GradientColor_android_startColor = 0;
        public static int GradientColor_android_startX = 8;
        public static int GradientColor_android_startY = 9;
        public static int GradientColor_android_tileMode = 6;
        public static int GradientColor_android_type = 2;
        public static int[] LoadingImageView;
        public static int LoadingImageView_circleCrop = 0;
        public static int LoadingImageView_imageAspectRatio = 1;
        public static int LoadingImageView_imageAspectRatioAdjust = 2;
        public static int[] SignInButton;
        public static int SignInButton_buttonSize = 0;
        public static int SignInButton_colorScheme = 1;
        public static int SignInButton_scopeUris = 2;
        
        static {
            styleable.ColorStateListItem = new int[] { 16843173, 16843551, 16844359, 2130968619, 2130968832 };
            styleable.FontFamily = new int[] { 2130968796, 2130968797, 2130968798, 2130968799, 2130968800, 2130968801, 2130968802 };
            styleable.FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130968794, 2130968803, 2130968804, 2130968805, 2130969117 };
            styleable.GradientColor = new int[] { 16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051 };
            styleable.GradientColorItem = new int[] { 16843173, 16844052 };
            styleable.LoadingImageView = new int[] { 2130968681, 2130968820, 2130968821 };
            styleable.SignInButton = new int[] { 2130968660, 2130968704, 2130969009 };
        }
        
        private styleable() {
        }
    }
}
