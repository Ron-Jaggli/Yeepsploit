package com.aheaditec.talsec.security;

public class i1
{
    public final l0 a;
    public final c b;
    
    public i1(final l0 a) {
        this.a = a;
        this.b = null;
    }
    
    public i1(final l0 a, final c b) {
        this.a = a;
        this.b = b;
    }
    
    public l0 a() {
        return this.a;
    }
    
    public c b() {
        return this.b;
    }
    
    public interface a
    {
        void c();
    }
    
    public interface c
    {
        String a();
        
        void a(final int p0);
        
        String b();
    }
}
