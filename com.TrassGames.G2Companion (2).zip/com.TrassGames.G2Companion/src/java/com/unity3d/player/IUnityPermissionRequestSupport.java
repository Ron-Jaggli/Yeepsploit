package com.unity3d.player;

public interface IUnityPermissionRequestSupport
{
    void requestPermissions(final PermissionRequest p0);
}
