package com.aheaditec.talsec.security;

import android.content.Context;

public final class j0 extends n
{
    public final I0 d;
    
    public j0(final I0 d, final u1 u1, final E1 e1) {
        super(u1, e1);
        this.d = d;
    }
    
    public void a() {
        this.a(this.d.a());
    }
    
    public void a(final Context context) {
        this.a(this.d.a());
    }
}
