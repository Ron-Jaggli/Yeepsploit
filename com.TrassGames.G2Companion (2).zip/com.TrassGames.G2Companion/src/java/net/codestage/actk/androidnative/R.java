package net.codestage.actk.androidnative;

public final class R
{
    private R() {
    }
    
    public static final class string
    {
        public static int app_name = 2131623969;
        
        private string() {
        }
    }
}
