package com.unity3d.player;

final class b1 implements I
{
    final d1 a;
    
    b1(final d1 a) {
        this.a = a;
    }
}
