package com.aheaditec.talsec.security;

import android.util.Log;

public class n1
{
    public static void a(final Exception ex) {
    }
    
    public static void a(final String s, final String s2) {
        Log.d(s, s2);
    }
    
    public static void b(final String s, final String s2) {
        Log.e(s, s2);
    }
    
    public static void c(final String s, final String s2) {
        Log.i(s, s2);
    }
    
    public static void d(final String s, final String s2) {
        Log.v(s, s2);
    }
    
    public static void e(final String s, final String s2) {
        Log.w(s, s2);
    }
}
