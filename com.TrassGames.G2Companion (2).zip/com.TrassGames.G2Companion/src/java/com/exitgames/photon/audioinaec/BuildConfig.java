package com.exitgames.photon.audioinaec;

public final class BuildConfig
{
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "com.exitgames.photon.audioinaec";
}
