package com.exitgames.photon.audioinaec;

public class ThreadUtils
{
    public static void checkIsOnMainThread() {
    }
    
    public static class ThreadChecker
    {
        private Thread thread;
        
        public ThreadChecker() {
            this.thread = Thread.currentThread();
        }
        
        public void checkIsOnValidThread() {
            if (this.thread == null) {
                this.thread = Thread.currentThread();
            }
            if (Thread.currentThread() == this.thread) {
                return;
            }
            throw new IllegalStateException("Wrong thread");
        }
        
        public void detachThread() {
            this.thread = null;
        }
    }
}
