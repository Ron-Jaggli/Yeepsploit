package com.unity3d.player;

final class x1 implements J
{
    final y1 a;
    
    x1(final y1 a) {
        this.a = a;
    }
    
    public final void a() {
        UnityPlayerForActivityOrService.-$$Nest$mnativeSoftInputLostFocus(this.a.m);
        this.a.m.reportSoftInputStr((String)null, 1, false);
    }
}
