package com.unity3d.player;

import android.view.MotionEvent;
import android.view.View;
import android.view.View$OnTouchListener;

final class a implements View$OnTouchListener
{
    public final boolean onTouch(final View view, final MotionEvent motionEvent) {
        return true;
    }
}
