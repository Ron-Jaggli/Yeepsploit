package com.fingerprintjs.android.fingerprint;

public final class R
{
    private R() {
    }
}
