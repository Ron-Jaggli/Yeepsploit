package com.unity3d.player;

import android.view.Surface;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CameraCaptureSession;

final class x extends v
{
    x(final z z) {
        super(z);
    }
    
    public final void onCaptureBufferLost(final CameraCaptureSession cameraCaptureSession, final CaptureRequest captureRequest, final Surface surface, final long n) {
    }
}
